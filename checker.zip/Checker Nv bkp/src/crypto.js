import { createHash } from "crypto";
import CryptoJS from "crypto-js";

export const STATIC_TOKEN = "b2e3d672-9d88-47a7-81b4-9d7ffc62054f";

const SESSION_IV = CryptoJS.enc.Utf8.parse("5421698523412578");

const LEGACY_IV = CryptoJS.lib.WordArray.create(
  [892613169, 909719605, 842216497, 842348344],
  16,
);

export function legacyDecrypt(encryptedData, key) {
  try {
    const parsedKey = CryptoJS.enc.Utf8.parse(key);
    const decrypted = CryptoJS.AES.decrypt(encryptedData, parsedKey, {
      iv: LEGACY_IV,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const plain = decrypted.toString(CryptoJS.enc.Utf8);
    if (!plain || plain.trim() === "") return null;
    return JSON.parse(plain);
  } catch {
    return null;
  }
}

export function derivePreLoginKey(token) {
  const inner = createHash("md5").update(token).digest("hex");
  const outer = createHash("md5").update(token + inner).digest("hex");
  return outer.slice(2, 18);
}

export function sessionEncrypt(data, aesKey) {
  const key = CryptoJS.enc.Utf8.parse(aesKey);
  const encrypted = CryptoJS.AES.encrypt(
    typeof data === "string" ? data : JSON.stringify(data),
    key,
    { iv: SESSION_IV, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 },
  );
  return encrypted.toString();
}

export function sessionDecrypt(cipherB64, aesKey) {
  if (typeof cipherB64 === "string" && cipherB64.trim().startsWith("{")) {
    try { return JSON.parse(cipherB64); } catch {}
  }
  const trimmed = cipherB64.replace(/^"|"$/g, "");
  try {
    const key = CryptoJS.enc.Utf8.parse(aesKey);
    const dec = CryptoJS.AES.decrypt(trimmed, key, {
      iv: SESSION_IV,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const plain = dec.toString(CryptoJS.enc.Utf8);
    let depth = 0, end = 0;
    for (let i = 0; i < plain.length; i++) {
      if (plain[i] === "{") depth++;
      else if (plain[i] === "}") {
        depth--;
        if (depth === 0) { end = i + 1; break; }
      }
    }
    return JSON.parse(end > 0 ? plain.slice(0, end) : plain);
  } catch {
    return null;
  }
}
