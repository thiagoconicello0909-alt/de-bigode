import readline from "readline";

const R = "\x1b[31m";
const B = "\x1b[1m";
const DIM = "\x1b[2m";
const RESET = "\x1b[0m";
const CYAN = "\x1b[36m";
const YELLOW = "\x1b[33m";
const GREEN = "\x1b[32m";

export const c = { R, B, DIM, RESET, CYAN, YELLOW, GREEN };

export function banner() {
  try {
    process.stdout.write("\u001b[2J\u001b[3J\u001b[H");
  } catch {
    console.clear();
  }
  console.log(`  ██████╗██╗     ███████╗██████╗ ██╗███╗   ██╗██╗  ██╗ ██████╗ `);
  console.log(` ██╔════╝██║     ██╔════╝██╔══██╗██║████╗  ██║██║  ██║██╔═══██╗`);
  console.log(` ██║     ██║     █████╗  ██████╔╝██║██╔██╗ ██║███████║██║   ██║`);
  console.log(` ██║     ██║     ██╔══╝  ██╔══██╗██║██║╚██╗██║██╔══██║██║   ██║`);
  console.log(` ╚██████╗███████╗███████╗██████╔╝██║██║ ╚████║██║  ██║╚██████╔╝`);
  console.log(`  ╚═════╝╚══════╝╚══════╝╚═════╝ ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ `);
  console.log(`${RESET}`);
  console.log(`${DIM}  ─────────────────────  C H E C K E R  ─────────────────────${RESET}`);
  console.log();
}

export function prompt(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => {
    rl.question(question, (answer) => { rl.close(); resolve(answer.trim()); });
  });
}

export async function readMultiline(message) {
  console.log(message);
  console.log(`${DIM}  (Cole o curl e pressione Enter duas vezes para finalizar)${RESET}\n`);
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const lines = [];
  let emptyCount = 0;
  return new Promise((resolve) => {
    rl.on("line", (line) => {
      if (line === "") {
        emptyCount++;
        if (emptyCount >= 1 && lines.length > 0) { rl.close(); resolve(lines.join("\n")); }
      } else {
        emptyCount = 0;
        lines.push(line);
      }
    });
    rl.on("close", () => resolve(lines.join("\n")));
  });
}

export async function menu(title, options) {
  console.log(`${CYAN}${B}  ${title}${RESET}`);
  console.log(`  ${DIM}${"─".repeat(40)}${RESET}`);
  options.forEach((opt, i) => {
    console.log(`  ${YELLOW}[${i + 1}]${RESET} ${opt}`);
  });
  console.log(`  ${YELLOW}[0]${RESET} Voltar / Sair`);
  console.log();
  const choice = await prompt(`  ${B}→${RESET} Escolha: `);
  return parseInt(choice, 10);
}

export function separator() {
  console.log(`\n  ${DIM}${"─".repeat(50)}${RESET}\n`);
}

export async function pressEnter() {
  await prompt(`\n  ${DIM}Pressione Enter para continuar...${RESET}`);
}
