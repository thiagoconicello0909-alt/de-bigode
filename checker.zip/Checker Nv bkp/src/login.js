import { v4 as uuidv4 } from "uuid";
import {
  STATIC_TOKEN, derivePreLoginKey, sessionEncrypt,
  sessionDecrypt, legacyDecrypt,
} from "./crypto.js";
import { buildHeaders } from "./headers.js";
import { tlsPost } from "./tls.js";
import { loadCaptchaConfig, solveCaptcha } from "./captcha.js";

export async function doLogin(domain, siteCode, username, userpass, apiHost, isPanda = false) {
  const host = apiHost || domain;
  const url = isPanda
    ? `https://${host}/api/v1/member/login`
    : `https://${host}/hall/api/member/login`;

  const aesKey = derivePreLoginKey(STATIC_TOKEN);

  const payload = isPanda ? {
    domain,
    username,
    password: userpass,
    clientType: 5,
    loginType: 1,
    deviceModel: "Chrome v146.0.0.0",
    osType: 4,
    version: "1.1.97",
    time: Math.floor(Date.now() / 1000),
  } : {
    domain, clientType: 5, jpush_id: "", loginId: uuidv4(),
    os_type: 4, deviceOsType: 4, deviceModel: "Chrome v146.0.0.0",
    platformType: "1001", operationId: 0, pkgId: 1, fromClub: 2,
    networkType: "UNKNOWN", version: 8, loginType: 1,
    username, userpass, geeToken: "disabled",
    time: Math.floor(Date.now() / 1000),
  };

  const encStr = sessionEncrypt(payload, aesKey);
  const body = JSON.stringify({ encryptString: encStr });
  const headers = {
    ...buildHeaders(domain, siteCode),
    "Content-Length": Buffer.byteLength(body).toString(),
    "content-length": Buffer.byteLength(body).toString(),
  };

  function decodeRaw(raw) {
    if (!raw) return null;
    if (typeof raw === "object") {
      if (raw.encryptString) return sessionDecrypt(raw.encryptString, aesKey);
      return raw;
    }
    if (typeof raw === "string") {
      try {
        const parsed = JSON.parse(raw);
        if (parsed?.encryptString) return sessionDecrypt(parsed.encryptString, aesKey);
        return parsed;
      } catch { }
      const s = sessionDecrypt(raw, aesKey);
      if (s) return s;
      const l = legacyDecrypt(raw, aesKey);
      if (l) return l;
      return { _raw: raw };
    }
    return raw;
  }

  try {
    const raw = await tlsPost(url, headers, body);
    const firstRes = decodeRaw(raw);
    if (!firstRes) return null;

    const code = firstRes.code ?? firstRes.errorCode ?? firstRes.err ?? firstRes.status;
    const msg = String(firstRes.msg || firstRes.message || firstRes.errorMsg || "").toLowerCase();

    // Se for código de captcha (ex: 1135 ou se a msg contiver captcha/geetest)
    const isCaptchaError = code === 1135 || code === 10005 || msg.includes("captcha") || msg.includes("geetest") || msg.includes("verify") || msg.includes("verification") || (msg.includes("verif") && !msg.includes("verifique"));

    if (isCaptchaError) {
      // O captchaId normalmente vem no campo msg (ex: "9ia4hndgblg9xihxcwgdjt9ztg8sjwaf")
      const captchaId = firstRes.msg || (firstRes.data && (firstRes.data.captchaId || firstRes.data.challenge || firstRes.data.gt));

      if (captchaId && captchaId.length >= 20) {
        const config = loadCaptchaConfig();
        if (config && config.provider !== "disabled") {
          const token = await solveCaptcha(domain, siteCode, username, captchaId);
          if (token) {

            // Recria o payload com o token resolvido
            const retryPayload = isPanda ? {
              domain,
              username,
              password: userpass,
              clientType: 5,
              loginType: 1,
              deviceModel: "Chrome v146.0.0.0",
              osType: 4,
              version: "1.1.97",
              time: Math.floor(Date.now() / 1000),
              geeToken: token,
            } : {
              domain, clientType: 5, jpush_id: "", loginId: uuidv4(),
              os_type: 4, deviceOsType: 4, deviceModel: "Chrome v146.0.0.0",
              platformType: "1001", operationId: 0, pkgId: 1, fromClub: 2,
              networkType: "UNKNOWN", version: 8, loginType: 1,
              username, userpass, geeToken: token,
              time: Math.floor(Date.now() / 1000),
            };

            const encStrRetry = sessionEncrypt(retryPayload, aesKey);
            const bodyRetry = JSON.stringify({ encryptString: encStrRetry });
            const headersRetry = {
              ...headers,
              "Content-Length": Buffer.byteLength(bodyRetry).toString(),
              "content-length": Buffer.byteLength(bodyRetry).toString(),
            };

            const rawRetry = await tlsPost(url, headersRetry, bodyRetry);
            return decodeRaw(rawRetry);
          }
        }
      }
    }
    return firstRes;
  } catch (e) {
    return { _error: e.message };
  }
}

export function getAccountDetails(loginData) {
  const d = (loginData.data && typeof loginData.data === "object") ? loginData.data : loginData;

  const userId = d.username || d.account || d.userId;
  const balance = d.game_gold ?? d.goldCoin ?? d.balance ?? d.gold ?? d.money ?? null;
  const vip = d.vip_level ?? d.vipLevel ?? d.vip ?? null;
  const bonusReq = parseFloat(d.bonusRequireBet || d.withdraw_limit || 0);
  const bonus = parseFloat(d.bonus || 0);
  const rollover = bonusReq > 0 ? bonusReq - bonus : null;
  const cpf = d.cpf || d.tax_id || "";
  const realname = d.realname || d.full_name || "";
  const deposits = d.deposit_count ?? d.total_deposit_count ?? null;
  const withdraws = d.withdrawCount ?? d.total_withdraw_count ?? null;
  const rawStatus = d.user_status ?? d.status ?? null;
  const statusStr =
    (rawStatus === 1 || rawStatus === 2 || rawStatus === "active") ? "ativa" :
      (rawStatus === 7 || rawStatus === 8 || rawStatus === "blocked" || rawStatus === "frozen") ? "proibida" :
        rawStatus !== null ? `status=${rawStatus}` : "";

  return { userId, balance, vip, rollover, cpf, realname, deposits, withdraws, statusStr };
}

export function interpretResult(result, debug = false) {
  if (!result) return { status: "ERRO", detail: "resposta nula" };
  if (result._error) return { status: "ERRO", detail: result._error };

  if (debug) console.log("  [DEBUG raw]", JSON.stringify(result));

  const inner = (result.data && typeof result.data === "object") ? result.data : result;
  const code = result.code ?? result.errorCode ?? result.err ?? result.status ?? inner.code ?? inner.errorCode;
  const msg = (
    result.msg || result.message || result.errorMsg || result.error ||
    inner.msg || inner.message || inner.errorMsg || ""
  ).toString().toLowerCase();

  if (
    code === 0 || code === "0" || code === 200 || code === "200" ||
    result.token || inner.token || result.userId || inner.userId ||
    result.uid || inner.uid || result.memberId || inner.memberId ||
    result.username || inner.username || result.account || inner.account
  ) {
    const name = inner.username || inner.nickname || inner.userId || result.userId || inner.account || "";
    return { status: "✅ EXISTE", detail: `code=${code}${name ? " user=" + name : ""}` };
  }

  if (
    msg.includes("not exist") || msg.includes("não existe") ||
    msg.includes("user not found") || msg.includes("account not exist") ||
    msg.includes("no exist") || msg.includes("inexist") ||
    msg.includes("usuário não") || msg.includes("nao existe") ||
    code === 10003 || code === 40001 || code === 1003 || code === 4001 || code === 10001
  ) {
    return { status: "❌ NÃO EXISTE", detail: msg || `code=${code}` };
  }

  if (
    code === 2006 ||
    msg.includes("exceção de parâmetro") || msg.includes("parameter") || msg.includes("parâmetro")
  ) {
    return { status: "❌ FORMATO INVÁLIDO", detail: msg || `code=${code}` };
  }

  if (
    msg.includes("password") || msg.includes("senha") ||
    msg.includes("incorrect") || msg.includes("incorreta") ||
    msg.includes("wrong") || msg.includes("errada") || msg.includes("invalid") ||
    code === 10004 || code === 40002 || code === 1004 || code === 4002 || code === 10002
  ) {
    return { status: "⚠️  EXISTE (senha errada)", detail: msg || `code=${code}` };
  }

  if (
    msg.includes("captcha") || msg.includes("geetest") || msg.includes("verify") || msg.includes("verification") || (msg.includes("verif") && !msg.includes("verifique"))
  ) {
    return { status: "⚠️  EXISTE? (captcha)", detail: msg || `code=${code}` };
  }

  if (
    msg.includes("blocked") || msg.includes("bloqueado") || msg.includes("freeze") ||
    msg.includes("risk") || msg.includes("abnormal")
  ) {
    return { status: "🚫 PROIBIDA", detail: msg || `code=${code}` };
  }

  return {
    status: "⚠️  INCONCLUSIVO",
    detail: `code=${code} msg=${msg || "(vazio)"} keys=${Object.keys(result).join(",")}`,
  };
}
