import fs from "fs";
import path from "path";
import axios from "axios";
import { ROOT } from "./paths.js";

const CONFIG_FILE = path.join(ROOT, "db", "captcha_config.json");

let _cachedConfig = null;

export function loadCaptchaConfig() {
  if (_cachedConfig !== null) {
    return _cachedConfig;
  }
  if (!fs.existsSync(CONFIG_FILE)) {
    const defaultConfig = {
      provider: "disabled", // "disabled", "custom", "capsolver", "2captcha", "anticaptcha"
      apiKey: "",
      customApiUrl: "",
    };
    saveCaptchaConfig(defaultConfig);
    _cachedConfig = defaultConfig;
    return defaultConfig;
  }
  try {
    _cachedConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
    return _cachedConfig;
  } catch {
    return { provider: "disabled", apiKey: "", customApiUrl: "" };
  }
}

export function saveCaptchaConfig(config) {
  _cachedConfig = config;
  const dir = path.dirname(CONFIG_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf-8");
}

export async function solveCaptcha(domain, siteCode, username, captchaId) {
  const config = loadCaptchaConfig();
  if (!config || config.provider === "disabled") {
    return null;
  }

  const cleanDomain = domain.replace(/^https?:\/\//, "");

  if (config.provider === "custom") {
    if (!config.customApiUrl) {
      console.error("❌ URL da API customizada não configurada em captcha_config.json");
      return null;
    }

    let url = config.customApiUrl
      .replace("{domain}", encodeURIComponent(cleanDomain))
      .replace("{siteCode}", encodeURIComponent(siteCode))
      .replace("{username}", encodeURIComponent(username || ""))
      .replace("{captchaId}", encodeURIComponent(captchaId || ""));

    try {
      const response = await axios.get(url, { timeout: 20000 });
      let data = response.data;
      if (!data) return null;

      // Se for string, tentamos fazer parse caso seja um JSON stringificado
      if (typeof data === "string") {
        try {
          data = JSON.parse(data);
        } catch {}
      }

      if (typeof data === "object") {
        // Se for um objeto com a estrutura do Geetest v4 (lot_number, etc)
        if (data.lot_number || data.pass_token) {
          return JSON.stringify(data);
        }
        // Procura por chaves comuns de token
        const token = data.geeToken || data.geetoken || data.token || data.data || data.result;
        if (token) {
          return typeof token === "object" ? JSON.stringify(token) : String(token);
        }
        return JSON.stringify(data);
      }

      return String(data).trim();
    } catch (error) {
      console.error(`❌ Erro ao chamar API customizada: ${error.message}`);
      return null;
    }
  }

  if (config.provider === "capsolver") {
    if (!config.apiKey) {
      console.error("❌ API Key do CapSolver não configurada em captcha_config.json");
      return null;
    }

    try {
      const taskRes = await axios.post("https://api.capsolver.com/createTask", {
        clientKey: config.apiKey,
        task: {
          type: "GeeTestTaskProxyless",
          websiteURL: `https://${cleanDomain}`,
          captchaId: captchaId,
        },
      });

      if (taskRes.data?.errorId !== 0) {
        console.error(`❌ CapSolver erro ao criar tarefa: ${JSON.stringify(taskRes.data)}`);
        return null;
      }

      const taskId = taskRes.data.taskId;
      // Loop de polling
      for (let i = 0; i < 30; i++) {
        await new Promise((resolve) => setTimeout(resolve, 2000));
        const res = await axios.post("https://api.capsolver.com/getTaskResult", {
          clientKey: config.apiKey,
          taskId: taskId,
        });

        if (res.data?.status === "ready") {
          return JSON.stringify({
            captcha_id: captchaId,
            ...res.data.solution,
          });
        } else if (res.data?.status === "failed" || res.data?.errorId !== 0) {
          console.error(`❌ CapSolver falhou: ${JSON.stringify(res.data)}`);
          return null;
        }
      }
      console.error("❌ CapSolver timeout");
      return null;
    } catch (error) {
      console.error(`❌ Erro no CapSolver: ${error.message}`);
      return null;
    }
  }

  if (config.provider === "2captcha") {
    if (!config.apiKey) {
      console.error("❌ API Key do 2Captcha não configurada em captcha_config.json");
      return null;
    }

    try {
      const createRes = await axios.get("https://2captcha.com/in.php", {
        params: {
          key: config.apiKey,
          method: "geetest_v4",
          captcha_id: captchaId,
          pageurl: `https://${cleanDomain}`,
          json: 1,
        },
      });

      if (createRes.data?.status !== 1) {
        console.error(`❌ 2Captcha erro ao criar tarefa: ${JSON.stringify(createRes.data)}`);
        return null;
      }

      const taskId = createRes.data.request;
      // Loop de polling
      for (let i = 0; i < 30; i++) {
        await new Promise((resolve) => setTimeout(resolve, 2000));
        const res = await axios.get("https://2captcha.com/res.php", {
          params: {
            key: config.apiKey,
            action: "get",
            id: taskId,
            json: 1,
          },
        });

        if (res.data?.status === 1) {
          const solution = res.data.request;
          return JSON.stringify({
            captcha_id: captchaId,
            ...(typeof solution === "string" ? JSON.parse(solution) : solution),
          });
        } else if (res.data?.request !== "CAPCHA_NOT_READY") {
          console.error(`❌ 2Captcha falhou: ${JSON.stringify(res.data)}`);
          return null;
        }
      }
      console.error("❌ 2Captcha timeout");
      return null;
    } catch (error) {
      console.error(`❌ Erro no 2Captcha: ${error.message}`);
      return null;
    }
  }

  if (config.provider === "anticaptcha") {
    if (!config.apiKey) {
      console.error("❌ API Key do Anti-Captcha não configurada em captcha_config.json");
      return null;
    }

    try {
      const taskRes = await axios.post("https://api.anti-captcha.com/createTask", {
        clientKey: config.apiKey,
        task: {
          type: "GeeTestTaskProxyless",
          websiteURL: `https://${cleanDomain}`,
          gt: captchaId,
          version: 4,
        },
      });

      if (taskRes.data?.errorId !== 0) {
        console.error(`❌ Anti-Captcha erro ao criar tarefa: ${JSON.stringify(taskRes.data)}`);
        return null;
      }

      const taskId = taskRes.data.taskId;
      // Loop de polling
      for (let i = 0; i < 30; i++) {
        await new Promise((resolve) => setTimeout(resolve, 2000));
        const res = await axios.post("https://api.anti-captcha.com/getTaskResult", {
          clientKey: config.apiKey,
          taskId: taskId,
        });

        if (res.data?.status === "ready") {
          return JSON.stringify({
            captcha_id: captchaId,
            ...res.data.solution,
          });
        } else if (res.data?.errorId !== 0) {
          console.error(`❌ Anti-Captcha falhou: ${JSON.stringify(res.data)}`);
          return null;
        }
      }
      console.error("❌ Anti-Captcha timeout");
      return null;
    } catch (error) {
      console.error(`❌ Erro no Anti-Captcha: ${error.message}`);
      return null;
    }
  }

  return null;
}
