export async function runPool(tasks, concurrency) {
  const iter = tasks[Symbol.iterator]();
  let running = 0, done = 0;
  const total = tasks.length;
  return new Promise((resolve) => {
    function next() {
      while (running < concurrency) {
        const { value, done: ended } = iter.next();
        if (ended) { if (running === 0) resolve(); return; }
        running++;
        value().finally(() => { running--; done++; next(); if (done === total) resolve(); });
      }
    }
    next();
  });
}
