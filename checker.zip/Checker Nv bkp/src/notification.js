import fs from "fs";
import { exec } from "child_process";
import path from "path";
import os from "os";

/**
 * Sends a Windows desktop notification (Toast) containing platform, balance, and account info.
 * @param {string} platform - The name or domain of the platform
 * @param {string} balance - The account balance (e.g. R$10.00)
 * @param {string} account - The account username/email
 */
export function sendDesktopNotification(platform, balance, account) {
  const tempFile = path.join(os.tmpdir(), `notify_${Date.now()}_${Math.floor(Math.random() * 1000)}.ps1`);
  
  // Windows PowerShell Toast XML template
  const script = `
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

$xml = @"
<toast>
    <visual>
        <binding template="ToastGeneric">
            <text>HIT na Plataforma - ${platform}</text>
            <text>Saldo: ${balance} | Conta: ${account}</text>
        </binding>
    </visual>
</toast>
"@

$XmlDocument = New-Object Windows.Data.Xml.Dom.XmlDocument
$XmlDocument.LoadXml($xml)
$Toast = New-Object Windows.UI.Notifications.ToastNotification $XmlDocument
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Google.AntigravityIDE").Show($Toast)
`;

  try {
    fs.writeFileSync(tempFile, script, "utf8");
    exec(`powershell -ExecutionPolicy Bypass -File "${tempFile}"`, () => {
      try {
        fs.unlinkSync(tempFile);
      } catch (e) {
        // ignore clean up error
      }
    });
  } catch (err) {
    console.error("Erro ao enviar notificação para a área de trabalho:", err.message);
  }
}
