
export function parseCurl(curlText) {
  // Tokenize shell quoting without executing the command or retaining its body.
  const tokens = [];
  const tokenPattern = /"((?:\\.|[^"\\])*)"|'([^']*)'|([^\s'"\\]+)|\\(.)/gs;
  let match;
  let token = "";
  let end = 0;
  for (match of curlText.matchAll(tokenPattern)) {
    if (/\s/.test(curlText.slice(end, match.index))) {
      if (token) tokens.push(token);
      token = "";
    }
    token += match[1] !== undefined
      ? match[1].replace(/\\(["\\$`])/g, "$1")
      : match[2] ?? match[3] ?? (match[4] === "\n" ? "" : match[4]);
    end = match.index + match[0].length;
  }
  if (token) tokens.push(token);

  const headers = {};
  let requestUrl = null;
  for (let i = 0; i < tokens.length; i++) {
    const value = tokens[i];
    let header;
    if (value === "-H" || value === "--header") header = tokens[++i];
    else if (value.startsWith("--header=")) header = value.slice(9);
    else if (value.startsWith("-H") && value.length > 2) header = value.slice(2);
    else if (value === "--url") requestUrl = tokens[++i];
    else if (value.startsWith("--url=")) requestUrl = value.slice(6);
    else if (!requestUrl && /^https?:\/\//i.test(value)) requestUrl = value;
    if (header) {
      const separator = header.indexOf(":");
      if (separator > 0) {
        headers[header.slice(0, separator).trim().toLowerCase()] = header.slice(separator + 1).trim();
      }
    }
  }
  const hostname = (value) => {
    try {
      const url = new URL(value);
      return ["http:", "https:"].includes(url.protocol) ? url.hostname : null;
    } catch { return null; }
  };
  const apiHost = hostname(requestUrl);
  const domain = headers.domain || hostname(headers.origin) || hostname(headers.referer) || apiHost;
  const siteCode = headers.sitecode || null;
  const tenantId = headers.tenantid || null;
  return { domain, siteCode, tenantId, apiHost: apiHost || domain };
}

export async function cmdPlatformAdd() {
  const curlText = await readMultiline("📋 Cole o comando curl da plataforma:");
  const { domain, siteCode, tenantId, apiHost } = parseCurl(curlText);

  if (!domain) {
    console.error("❌ Não consegui extrair o domain. Verifique o header 'domain:'");
    return;
  }
  if (!siteCode && !tenantId) {
    console.error("❌ Não consegui extrair o identificador. Verifique os headers 'sitecode:' ou 'tenantid:'");
    return;
  }

  console.log(`\n✅ Encontrado:  apiHost=${apiHost}  domain=${domain}  siteCode=${siteCode || "—"}  tenantId=${tenantId || "—"}`);
  const name = await prompt("📝 Nome para esta plataforma (ex: bet505, estrela): ");

  if (!name) { console.error("❌ Nome não pode ser vazio."); return; }

  const platforms = loadPlatforms();
  if (platforms[name]) {
    const confirm = await prompt(`⚠️  Já existe '${name}' (${platforms[name].domain}). Sobrescrever? [s/N] `);
    if (confirm.toLowerCase() !== "s") { console.log("Cancelado."); return; }
  }

  platforms[name] = { domain, apiHost, ...(siteCode ? { siteCode } : {}), ...(tenantId ? { tenantId } : {}) };
  savePlatforms(platforms);
  console.log(`\n✅ Plataforma '${name}' salva!\n`);
}

export function cmdPlatformList() {
  const platforms = loadPlatforms();
  const entries = Object.entries(platforms);
  if (entries.length === 0) {
    console.log("\n  Nenhuma plataforma cadastrada.\n");
    return;
  }
  console.log("\n  📋 Plataformas cadastradas:");
  console.log("  " + "─".repeat(70));
  for (const [name, p] of entries) {
    const api = p.apiHost || p.domain;
    console.log(`  ${name.padEnd(15)} domain=${p.domain.padEnd(28)} api=${api.padEnd(28)} siteCode=${p.siteCode || "—"} tenantId=${p.tenantId || "—"}`);
  }
  console.log("  " + "─".repeat(70) + "\n");
}

export async function cmdPlatformRemove() {
  const platforms = loadPlatforms();
  const keys = Object.keys(platforms);
  if (keys.length === 0) { console.log("\n  Nenhuma plataforma cadastrada.\n"); return; }

  console.log("\n  📋 Escolha a plataforma para remover:");
  console.log("  " + "─".repeat(50));
  keys.forEach((key, index) => {
    console.log(`  [${index + 1}] ${key} (${platforms[key].domain})`);
  });
  console.log("  [0] Cancelar");
  console.log("  " + "─".repeat(50) + "\n");

  const choice = await prompt("  Escolha o número ou digite o nome da plataforma: ");
  if (!choice || choice.trim() === "0") return;

  let name = choice.trim();
  const index = parseInt(name, 10);
  if (!isNaN(index) && index > 0 && index <= keys.length) {
    name = keys[index - 1];
  }

  if (!platforms[name]) { console.error(`\n❌ Plataforma '${name}' não encontrada.`); return; }

  const confirm = await prompt(`⚠️  Tem certeza que deseja remover a plataforma '${name}'? [s/N]: `);
  if (confirm.toLowerCase() !== "s") { console.log("Cancelado."); return; }

  delete platforms[name];
  savePlatforms(platforms);
  console.log(`✅ Plataforma '${name}' removida.\n`);
}

export async function cmdPlatformRemoveAll() {
  const platforms = loadPlatforms();
  const keys = Object.keys(platforms);
  if (keys.length === 0) { console.log("\n  Nenhuma plataforma cadastrada.\n"); return; }

  const confirm = await prompt(`⚠️  Tem certeza que deseja excluir TODAS as ${keys.length} plataformas cadastradas? Essa ação não pode ser desfeita! [s/N]: `);
  if (confirm.toLowerCase() !== "s") { console.log("Cancelado."); return; }

  savePlatforms({});
  console.log("✅ Todas as plataformas foram excluídas!\n");
}
