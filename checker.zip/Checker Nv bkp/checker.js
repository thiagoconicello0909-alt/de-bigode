import { banner, menu, pressEnter, c } from "./src/ui.js";
import { cmdPlatformAdd, cmdPlatformList, cmdPlatformRemove, cmdPlatformRemoveAll } from "./src/platforms.js";
import { cmdRun } from "./src/run.js";
import { loadCaptchaConfig, saveCaptchaConfig } from "./src/captcha.js";

async function menuPlatforms() {
  while (true) {
    banner();
    const choice = await menu("Gerenciar Plataformas", [
      "Adicionar plataforma  (colar curl)",
      "Listar plataformas",
      "Remover plataforma específica",
      "Excluir TODAS as plataformas",
    ]);

    if (choice === 0) return;

    banner();
    if (choice === 1) {
      await cmdPlatformAdd();
      await pressEnter();
    } else if (choice === 2) {
      cmdPlatformList();
      await pressEnter();
    } else if (choice === 3) {
      await cmdPlatformRemove();
      await pressEnter();
    } else if (choice === 4) {
      await cmdPlatformRemoveAll();
      await pressEnter();
    }
  }
}

async function menuChecker() {
  banner();
  await cmdRun();
  await pressEnter();
}

async function menuCaptcha() {
  while (true) {
    banner();
    const config = loadCaptchaConfig();
    console.log(`  Provedor atual: ${c.YELLOW}${config.provider.toUpperCase()}${c.RESET}`);
    if (config.provider === "custom") {
      console.log(`  URL da API:     ${c.DIM}${config.customApiUrl || "não configurada"}${c.RESET}`);
    } else if (config.provider !== "disabled") {
      console.log(`  Chave API:      ${c.DIM}${config.apiKey ? "********" : "não configurada"}${c.RESET}`);
    }
    console.log();

    const choice = await menu("Configurar Captcha / geeToken", [
      "Usar URL de API Customizada",
      "Usar CapSolver",
      "Usar 2Captcha",
      "Usar Anti-Captcha",
      "Desativar Captcha Solver",
    ]);

    if (choice === 0) return;

    banner();
    if (choice === 1) {
      const url = await prompt("Cole a URL da API (use {domain}, {siteCode}, {username}, {captchaId} como marcadores):\n> ");
      if (url) {
        saveCaptchaConfig({ provider: "custom", apiKey: "", customApiUrl: url });
        console.log("\n✅ Configuração salva!");
        await pressEnter();
      }
    } else if (choice === 2) {
      const key = await prompt("Cole sua API Key do CapSolver:\n> ");
      if (key) {
        saveCaptchaConfig({ provider: "capsolver", apiKey: key, customApiUrl: "" });
        console.log("\n✅ Configuração salva!");
        await pressEnter();
      }
    } else if (choice === 3) {
      const key = await prompt("Cole sua API Key do 2Captcha:\n> ");
      if (key) {
        saveCaptchaConfig({ provider: "2captcha", apiKey: key, customApiUrl: "" });
        console.log("\n✅ Configuração salva!");
        await pressEnter();
      }
    } else if (choice === 4) {
      const key = await prompt("Cole sua API Key do Anti-Captcha:\n> ");
      if (key) {
        saveCaptchaConfig({ provider: "anticaptcha", apiKey: key, customApiUrl: "" });
        console.log("\n✅ Configuração salva!");
        await pressEnter();
      }
    } else if (choice === 5) {
      saveCaptchaConfig({ provider: "disabled", apiKey: "", customApiUrl: "" });
      console.log("\n✅ Captcha solver desativado!");
      await pressEnter();
    }
  }
}

async function main() {
  while (true) {
    banner();
    const choice = await menu("Menu Principal", [
      "Checar Contas",
      "Gerenciar Plataformas",
      "Configurar Captcha/GeeToken",
    ]);

    if (choice === 0) {
      console.log(`\n  ${c.DIM}Saindo...${c.RESET}\n`);
      process.exit(0);
    } else if (choice === 1) {
      await menuChecker();
    } else if (choice === 2) {
      await menuPlatforms();
    } else if (choice === 3) {
      await menuCaptcha();
    }
  }
}

main();
